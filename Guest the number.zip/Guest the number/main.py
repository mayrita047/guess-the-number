import random

def main():
    # Generate the secret number at random!
    secret_number = random.randint(1, 100)
    
    print("Welcome to the Guess the Number Game!")
    print("I'm thinking of a number between 1 and 100...")
            
    # Get user's guess
    while True:
        user_input = input("Enter a guess: ")

        # Check if input is a valid number
        if not user_input.isdigit():
            print("❌ Please enter a valid number, not a word!")
            continue  # Ask again

        guess = int(user_input)
        
        # True if guess is not equal to secret number
        while guess != secret_number:
            difference = abs(secret_number - guess)
            if guess < secret_number: 
                print("Nahh!! Your guess is too low.")
            else:
                print("Oops! Your guess is too high.")
            if difference <= 10:
                print("🔥You are very close!")   

            print() 
            while True:
                user_input = input("One more try: ")
                try:
                    guess = int(user_input)
                    break  # valid number, exit loop
                except ValueError:
                    print("❌ Value Error: You need a valid number!")
                
        print("Congrats! You guessed it!  The secret number was " + str(secret_number) + ".")
        #Ask if user wants to play again
        play_again = input("\nDo you want to play again? (yes/no): ")
        if play_again == 'yes':
            print("Great! Let's start again!")
        else:
            print("Thanks for playing! Goodbye! 👋")
            break
        
if __name__ == '__main__':
    main()

